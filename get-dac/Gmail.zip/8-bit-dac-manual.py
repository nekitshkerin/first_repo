"""Дополнение из задания 1: ручное управление 8-битным ЦАП без класса."""

import math
import RPi.GPIO as GPIO

dac_bits = [16, 20, 21, 25, 26, 17, 27, 22]
dynamic_range = 3.3


def voltage_to_number(voltage):
    if not math.isfinite(voltage) or not 0 <= voltage <= dynamic_range:
        print("Напряжение вне диапазона. Устанавливаем 0 В.")
        return 0
    return int(voltage / dynamic_range * 255)


def number_to_dac(number):
    if type(number) is not int or not 0 <= number <= 255:
        raise ValueError("Нужно целое число от 0 до 255")
    GPIO.output(dac_bits, [int(bit) for bit in format(number, "08b")])


def main():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(dac_bits, GPIO.OUT, initial=0)
    try:
        while True:
            try:
                voltage = float(input("Напряжение, В: "))
                number_to_dac(voltage_to_number(voltage))
            except ValueError:
                print("Введите число с точкой, например 1.5")
    except (KeyboardInterrupt, EOFError):
        print("\nОстановка")
    finally:
        try:
            GPIO.output(dac_bits, 0)
        finally:
            GPIO.cleanup(dac_bits)


if __name__ == "__main__":
    main()
