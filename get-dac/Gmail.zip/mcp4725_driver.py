"""Вспомогательный модуль из задания 4: MCP4725, I2C1, адрес 0x61."""

import math
import smbus


class MCP4725:
    def __init__(self, dynamic_range, address=0x61, verbose=False):
        if not math.isfinite(dynamic_range) or dynamic_range <= 0:
            raise ValueError("Диапазон ЦАП должен быть положительным")
        self.dynamic_range = dynamic_range
        self.address = address
        self.verbose = verbose
        self.bus = smbus.SMBus(1)

    def set_number(self, number):
        if type(number) is not int:
            raise TypeError("Код ЦАП должен быть целым числом")
        if not 0 <= number <= 4095:
            raise ValueError("12-битный код должен быть от 0 до 4095")

        # Fast Mode: настройки 0000, затем 4 старших бита кода.
        first_byte = (number >> 8) & 0x0F
        second_byte = number & 0xFF  # 8 младших битов кода.
        # Адресный байт I2C библиотека передаёт сама. EEPROM не записывается.
        self.bus.write_byte_data(self.address, first_byte, second_byte)
        if self.verbose:
            print(f"Код: {number}; данные: {first_byte:02X} {second_byte:02X}")

    def set_voltage(self, voltage):
        if not math.isfinite(voltage) or not 0 <= voltage <= self.dynamic_range:
            raise ValueError("Напряжение выходит за диапазон ЦАП")
        # dynamic_range здесь — напряжение при максимальном коде 4095.
        number = int(voltage / self.dynamic_range * 4095)
        self.set_number(number)

    def deinit(self):
        try:
            self.set_number(0)  # Закрытие шины само по себе не обнуляет ЦАП.
        finally:
            self.bus.close()


if __name__ == "__main__":
    dac = None
    try:
        dac = MCP4725(5.0, verbose=True)
        while True:
            try:
                dac.set_voltage(float(input("Напряжение, В: ")))
            except ValueError as error:
                print(error)
    except (KeyboardInterrupt, EOFError):
        print("\nОстановка")
    finally:
        if dac is not None:
            dac.deinit()
