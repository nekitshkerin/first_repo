"""Вспомогательный модуль из задания 2: 8-битный R2R-ЦАП."""

import math
import RPi.GPIO as GPIO


class R2R_DAC:
    def __init__(self, gpio_bits, dynamic_range, verbose=False):
        if len(gpio_bits) != 8:
            raise ValueError("Для 8-битного ЦАП нужны 8 GPIO-пинов")
        if not math.isfinite(dynamic_range) or dynamic_range <= 0:
            raise ValueError("Диапазон ЦАП должен быть положительным")
        self.gpio_bits = gpio_bits  # Порядок: от старшего бита к младшему.
        self.dynamic_range = dynamic_range
        self.verbose = verbose
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.gpio_bits, GPIO.OUT, initial=0)

    def set_number(self, number):
        if type(number) is not int:
            raise TypeError("Код ЦАП должен быть целым числом")
        if not 0 <= number <= 255:
            raise ValueError("8-битный код должен быть от 0 до 255")
        bits = [int(bit) for bit in format(number, "08b")]
        GPIO.output(self.gpio_bits, bits)
        if self.verbose:
            print(f"Код: {number}; биты: {bits}")

    def set_voltage(self, voltage):
        if not math.isfinite(voltage) or not 0 <= voltage <= self.dynamic_range:
            raise ValueError("Напряжение выходит за диапазон ЦАП")
        number = int(voltage / self.dynamic_range * 255)
        self.set_number(number)

    def deinit(self):
        try:
            GPIO.output(self.gpio_bits, 0)
        finally:
            GPIO.cleanup(self.gpio_bits)


if __name__ == "__main__":
    dac = None
    try:
        dac = R2R_DAC([16, 20, 21, 25, 26, 17, 27, 22], 3.3, verbose=True)
        while True:
            try:
                dac.set_voltage(float(input("Напряжение, В: ")))
            except ValueError as error:
                print(error)
    except (KeyboardInterrupt, EOFError):
        print("\nОстановка")
    finally:
        if dac is not None:
            dac.deinit()
